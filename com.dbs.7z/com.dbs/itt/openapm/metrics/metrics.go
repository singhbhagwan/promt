package openapmmetrics

import (
	"fmt"
	"log"
	"net/http"

	"github.com/prometheus/client_golang/prometheus/promhttp"
	metrics "github.com/slok/go-http-metrics/metrics/prometheus"
	"github.com/slok/go-http-metrics/middleware"
	"github.com/slok/go-http-metrics/middleware/std"
	"github.com/spf13/viper"
)
type Configurations struct {
	Server       ServerConfigurations
	Application string
}

// ServerConfigurations exported
type ServerConfigurations struct {
	Port string
}
var app string

func init() {

	viper.SetConfigName("monitoring-config")

	// Set the path to look for the configurations file
	viper.AddConfigPath("../")

	// Enable VIPER to read Environment Variables
	viper.AutomaticEnv()

	viper.SetConfigType("yml")
	var configuration Configurations

	if err := viper.ReadInConfig(); err != nil {
		fmt.Printf("Error reading config file, %s", err)
	}

	err := viper.Unmarshal(&configuration)
	if err != nil {
		fmt.Printf("Unable to decode into struct, %v", err)
	}
	app=configuration.Application
	
	// Serve our metrics.
	http.Handle("/metrics",promhttp.Handler())
	go func() {
		if err := http.ListenAndServe(":"+configuration.Server.Port, promhttp.Handler()); err != nil {
			log.Panicf("error while serving metrics: %s", err)
		}
	}()

}

func MiddlewareHandler(h http.Handler) http.Handler{

	mdlw:=middleware.New(middleware.Config{
		Service: app,
		Recorder: metrics.NewRecorder(metrics.Config{
		ServiceLabel: "Application",
		}),
	})
	return std.Handler("",mdlw,h)

}
